import java.util.Locale;
import java.util.Scanner;

class User{
    String username;
    String email;

    public User(String username, String email) {
        this.username = username;
        this.email = email;
    }
    void performRole(){
        System.out.println("Default user Performing");
    }
}

class Student extends User{
    int count=0;
 String [] enrolledcourses = new String[20];
 private String [] grades = new String[20];

     Student(String username, String email) {
        super(username, email);
    }
    void enrollCourse(String courseName){
        enrolledcourses[count++]=courseName;
    }
void  setGrade(int courseindex,String grade){
        grades[courseindex]=grade;
}
String getGrade(int courseindex){
        return grades[courseindex];
}

    @Override
    void performRole(){
        System.out.println("Student "+" "+super.username+" "+ "Enrolled into Courses :");
for (int i=0;i<count; i++){
    System.out.println(" "+enrolledcourses[i]);
}
    }
    void viewGrades(){
        System.out.println("Student :"+username);
        System.out.println("Grades:");
        for (int i=0;i<count;i++){
            System.out.println(enrolledcourses[i] +" : "+grades[i]);
        }
    }
}


class Teacher extends User{
String [] tcourses = new String[60];
int count =0;
Teacher(String username,String email){
    super(username,email);
}
void createcourse(String coursename){
    tcourses[count++]=coursename;
}

    @Override
    void performRole(){
        System.out.println("Teacher"+" "+super.username+" "+" teaches :");
        for (int i=0;i<count; i++){
            System.out.println(" "+tcourses[i]);
        }
    }

}


class Administrator extends User{
String [] manageusers = new String[60];
int count=0;
Administrator(String username,String  email){
    super(username,email);
}
void addUser(String userNAme){
if(count<manageusers.length) {
    manageusers[count++] = userNAme;
}
}
void deleteuser(String userNAme){

 for (int i=0;i<count;i++){
     if(manageusers[i].equals(userNAme)) {  
         for (int j = i; j < count - 1; j++) {
             manageusers[j] = manageusers[j + 1];
         }
         manageusers[--count] = null;
         break;
     }
 }
}
    @Override
    void performRole(){
        System.out.println("Administator"+" "+super.username+" "+" Manages :");
        System.out.println("Total  managed user :"+count);
        System.out.println();
        if(count>0) {
            System.out.println("List of Managed USERs:");
            for (int i = 0; i < count; i++) {
                System.out.println("> " + manageusers[i]);
            }
        }else{
            System.out.println("no user given to manage.Now time to sleep.");
        }
}
}


public class EducationalPlatform {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.print("How many students?");
        int  scount =sc.nextInt();
        sc.nextLine();
        System.out.print("How many teachers?");
        int tcount =sc.nextInt();
        sc.nextLine();
        System.out.print("how many administators?");
        int acount =sc.nextInt();
        sc.nextLine();

        Student []st=new Student[scount];
        Teacher []tr=new Teacher[tcount];
        Administrator []ad=new Administrator[acount];
        String [] allusers =new String[scount+tcount];
        int usernindex=0;

        User [] u =new User[scount+tcount+acount];
        int c=0;

        for (int i=0;i<scount;i++){
            System.out.println("Students info:");
            System.out.print("Name :");
            String name=sc.nextLine();

            System.out.print("Email :");
            String email=sc.nextLine();
            Student s =new Student(name,email);

            System.out.print("Enroll how many courses? ");
            int crs =sc.nextInt();
            sc.nextLine();
            for(int k=0;k<crs;k++){
                System.out.print("Course name :");
                String course =sc.nextLine();
                s.enrollCourse(course);

                System.out.print("Grade : ");
                String grade =sc.nextLine();
                s.setGrade(k,grade);

            }
            st[i]=s;
            u[c++]=s;
            allusers[usernindex++]=s.username;
        }

        for(int i=0;i<tcount;i++){
            System.out.println("Teachers info:");
            System.out.print("Name :");
            String name=sc.nextLine();
            System.out.print("Email :");
            String email=sc.nextLine();
            Teacher t=new Teacher(name,email);
            System.out.print("How many cources to teach ? ");
            int crss=sc.nextInt();
            sc.nextLine();

            for(int k=0;k<crss;k++) {
                System.out.print("Course name :");
                String course = sc.nextLine();
                t.createcourse(course);
            }
            tr[i]=t;
            u[c++]=t;
            allusers[usernindex++]=t.username;
        }

        int e=0;
        for(int i=0;i<acount;i++){
            System.out.println("Administrator info:");
            System.out.print("Name :");
            String name=sc.nextLine();
            System.out.print("Email :");
            String email=sc.nextLine();
           Administrator a=new Administrator(name,email);

        int usrforthadimin=allusers.length/acount;
        if(i<allusers.length % acount){
            usrforthadimin++;
        }
        for(int l=0;l<usrforthadimin;l++){
            if(e<allusers.length && allusers[e]!= null){
                System.out.println();
                System.out.println("User : "+allusers[e]);
                System.out.println("what do you want: 1)Press (A) to add 2)Press (D)to delete >>");
                String choice=sc.nextLine().toUpperCase();
                if(choice.equals("A")){
                    a.addUser(allusers[e]);
                    System.out.println(allusers[e]+" "+"added successfully");
                } else if (choice.equals("D")) {
                    a.deleteuser(allusers[e]);
                    System.out.println(allusers[e]+" "+"deleted successfully");
                }else {
                    System.out.println("INVALID...");
                }
                e++;
            }
        }
           ad[i]=a;
           u[c++]=a;
        }
        System.out.println();
        System.out.println();
        System.out.println("USER INFOS : ");
        System.out.println();
        for (User x : u){
            x.performRole();
            System.out.println();
        }


        for (Student s :st){
            s.viewGrades();
            System.out.println();
        }
    }
}